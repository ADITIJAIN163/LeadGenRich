"""
Simple Agent with Google ADK
A reference implementation showing how to create an agent with custom tools.
"""

import asyncio
from google.adk.agents import LlmAgent
from google.adk.models.lite_llm import LiteLlm
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types
import os

os.environ["OPENAI_API_BASE"] = "http://localhost:4000"
os.environ["OPENAI_API_KEY"] = "sk-TE5BPNfSh4IOCNpW3I5EDQ"


# --- Constants ---
APP_NAME = "simple_agent_app"
USER_ID = "user_001"
SESSION_ID = "session_001"
MODEL_NAME = "claude-4-sonnet"  # LiteLLM model name


# --- Tool Definitions ---

def calculator(operation: str, a: float, b: float) -> float:
    """Performs basic arithmetic operations."""
    print(f"[Tool Call] calculator(operation='{operation}', a={a}, b={b})")
    
    if operation == "add":
        result = a + b
    elif operation == "subtract":
        result = a - b
    elif operation == "multiply":
        result = a * b
    elif operation == "divide":
        if b == 0:
            raise ValueError("Cannot divide by zero")
        result = a / b
    else:
        raise ValueError(f"Unknown operation: {operation}")
    
    print(f"[Tool Result] {result}")
    return result


def text_analyzer(text: str, analysis_type: str) -> dict:
    """Analyzes text and returns statistics."""
    print(f"[Tool Call] text_analyzer(text='{text[:50]}...', analysis_type='{analysis_type}')")
    
    if analysis_type == "word_count":
        result = {"word_count": len(text.split())}
    elif analysis_type == "char_count":
        result = {"char_count": len(text)}
    elif analysis_type == "word_list":
        words = text.split()
        result = {"words": words, "unique_words": len(set(words))}
    else:
        raise ValueError(f"Unknown analysis type: {analysis_type}")
    
    print(f"[Tool Result] {result}")
    return result



# --- Agent Configuration ---

simple_agent = LlmAgent(
    model=LiteLlm(model="openai/" + MODEL_NAME),
    name="simple_agent",
    description=(
        "A helpful assistant that can perform calculations and analyze text. "
        "It has access to a calculator for arithmetic operations and a text "
        "analyzer for text statistics."
    ),
    instruction="""You are a helpful assistant with access to tools for calculations and text analysis.

When asked to perform calculations, use the calculator tool.
When asked to analyze text, use the text_analyzer tool.

Be concise and clear in your responses. Always use the appropriate tool when available
rather than trying to compute answers yourself.
""",
    tools=[
        calculator,
        text_analyzer,
    ],
    output_key="simple_agent_response",
)


# --- Session Management and Runner Setup ---

session_service = InMemorySessionService()

runner = Runner(
    agent=simple_agent,
    app_name=APP_NAME,
    session_service=session_service
)


# --- Agent Interaction Functions ---

async def run_agent_async(query: str, user_id: str = USER_ID, session_id: str = SESSION_ID, verbose: bool = True) -> str:
    """
    Run the agent with a query asynchronously.
    
    Args:
        query: The question or prompt to send to the agent
        user_id: User identifier for the session
        session_id: Session identifier
        verbose: Whether to print detailed output
    
    Returns:
        The agent's response as a string
    """
    if verbose:
        print(f"\n>>> Query: {query}")
    
    # Create session if it doesn't exist
    try:
        await session_service.get_session(app_name=APP_NAME, user_id=user_id, session_id=session_id)
    except:
        await session_service.create_session(app_name=APP_NAME, user_id=user_id, session_id=session_id)
    
    user_content = types.Content(role='user', parts=[types.Part(text=query)])
    
    final_response = None
    async for event in runner.run_async(user_id=user_id, session_id=session_id, new_message=user_content):
        if event.is_final_response() and event.content and event.content.parts:
            final_response = event.content.parts[0].text
    
    if verbose:
        print(f"<<< Response: {final_response}\n")
    
    return final_response if final_response else "No response received."


def run_agent(query: str, user_id: str = USER_ID, session_id: str = SESSION_ID, verbose: bool = True) -> str:
    """
    Run the agent with a query (synchronous wrapper).
    
    Args:
        query: The question or prompt to send to the agent
        user_id: User identifier for the session
        session_id: Session identifier
        verbose: Whether to print detailed output
    
    Returns:
        The agent's response as a string
    """
    try:
        # Check if we're already in an event loop (like in Jupyter)
        loop = asyncio.get_running_loop()
        # If we're in a loop, we need to use a different approach
        import nest_asyncio
        nest_asyncio.apply()
        return asyncio.run(run_agent_async(query, user_id, session_id, verbose))
    except RuntimeError:
        # No running loop, safe to use asyncio.run()
        return asyncio.run(run_agent_async(query, user_id, session_id, verbose))


# --- Example Usage ---

async def main():
    """Example usage of the simple agent."""
    print("=" * 60)
    print("Simple Agent Demo")
    print("=" * 60)
    
    # Create session
    await session_service.create_session(app_name=APP_NAME, user_id=USER_ID, session_id=SESSION_ID)
    
    # Example 1: Calculator tool
    print("\n--- Example 1: Using Calculator Tool ---")
    await run_agent_async("What is 45 multiplied by 23?")
    
    # Example 2: Text analyzer tool
    print("\n--- Example 2: Using Text Analyzer Tool ---")
    await run_agent_async("How many words are in this sentence: 'The quick brown fox jumps over the lazy dog'?")
    
    # Example 3: Complex calculation
    print("\n--- Example 3: Complex Calculation ---")
    await run_agent_async("If I have 100 dollars and spend 25% of it, then add 50 dollars, how much do I have?")
    
    # Example 4: No tools needed
    print("\n--- Example 4: General Knowledge (No Tools) ---")
    await run_agent_async("What is the capital of France?")


if __name__ == "__main__":
    asyncio.run(main())
