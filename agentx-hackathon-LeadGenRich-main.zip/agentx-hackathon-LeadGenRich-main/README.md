<img width="3336" height="45" alt="image" src="https://github.com/user-attachments/assets/4ed9f3a6-c9f2-4d56-8330-4ce6f49d5b6c" />

# AgentX Hackathon

## LeadGenRich
LeadGenRich

## Team LeadGenRich
Team Innovators

---

## About the Project

**Problem Statement**
Lead Enrichment & ICP fit scoring (Cross Industry)-The lead enrichment process involves integrating multiple data sources to accurately profile and score incoming leads. There's a need for consistent, compact workflow that provides enriched output for downstream sales processes. The goal is to ensure routing based on a unified ICP scoring system.

**Our Solution**
We propose an agentic system where specialized nodes handle company and opportunity enrichment and scoring. We'll aggregate and use a weighted ICP scoring logic to evaluate fit. Finally, our routing agent assigns each enriched lead to the ideal SDR all within a clear, streamlined workflow


---

## Getting Started (Steps Involved to getting started with project)

### Prerequisites

- python
- Git
- OS: Windows, macOS, or Linux

### Steps to Run the Project

1. **Clone the repository:**
   ```bash
   git clone https://github.com/example/agentx-hackathon.git
   cd agentx-hackathon
   ```

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure environment:**
   - Copy `.env.example` to `.env` and update variables as needed.
   - You will be needing Serper API key, please get it from https://serper.dev/
   - Activate virtual env- source .venv/bin/activate

4. **Run backend file:**

```bash
  python start_backend.py 
   ```
5. **Run frontend file:**

```bash
  python start_frontend.py
   ```

6. **Open in browser:**
   - Visit ` http://localhost:8501` to view the app.

(Any further details related should be added here)

---

## Constraints

- Ensure all dependencies match the specified versions in `package.json`.
- Requires internet connectivity for API integrations.
- Local environment should not have any conflicting services running on ports.


---

## Tech Stack

- Frontend: Python Streamlit
- Backend: Python FastAPI
- Database: Sqlite


---

## Contributors

- Aditi Jain
- Prajwal S
- Dhanunjai Kasukurthi
- Prajapati, Ashish
  

---

## License

The data used is from Source and licensed under- 

---

## Contact

For any queries or support, reach out to teaminnovators@example.com.
