## Installing additional dependencies

Any additional dependencies required by your project can be added to the `requirements.txt` file located in the root directory of your project. These dependencies will be automatically installed when the codespace is created.

## AEF Components

### LLM Gateway

Read more about the LLM Gateway in the [llmgateway README](./aef-samples/llmgateway/README.md).

### Deval

Read more about Deval and usage in the notebook located at `aef-samples/deval/basic_Demo.ipynb` in this repository.

### Model Access

LLM Gateway in this codespace is pre-configured to access the following models:

LLMs:
- claude-4.5-sonnet
- claude-4.5-haiku
- claude-4-sonnet

Embeddings:
- titan-embed-text-v1

API key : sk-TE5BPNfSh4IOCNpW3I5EDQ

### Adding additional models to config.yaml

To add AWS Bedrock models to your LiteLLM configuration, edit the `configs/config.yaml` file. Follow the pattern of existing model entries:

#### Structure

Each model entry requires:
- `model_name`: A friendly name you'll use to reference the model in your code
- `litellm_params`:
  - `model`: The Bedrock model identifier in format `bedrock/<model-id>` or `bedrock/converse/<model-id>`
  - `aws_access_key_id`: Your AWS access key ID (can be set to read from environment variable)
  - `aws_secret_access_key`: Your AWS secret access key (can be set to read from environment variable)
  - `aws_region_name`: The AWS region name (can be set to read from environment variable)

#### Example Entry

```yaml
- model_name: your-model-alias
  litellm_params:
    model: bedrock/us.anthropic.claude-sonnet-4-20250514-v1:0
      aws_access_key_id: os.environ/AGENTX_AWS_ACCESS_KEY
      aws_secret_access_key: os.environ/AGENTX_AWS_SECRET_KEY
      aws_region_name: os.environ/AGENTX_AWS_REGION_NAME
```

#### Start LLM Gateway

To start the LLM Gateway with your updated configuration, run the following command in your terminal:

```bash
/opt/llm_gateway/start-llm-gateway.sh --config configs/config.yaml
```

### n8n

n8n is pre-installed in this codespace. You can access the n8n editor UI by navigating to port `5678` from the ports section. 

Credentials for n8n are pre-configured as follows:
- Username: `admin@deloitte.com`
- Password: `P@ssw0rd`