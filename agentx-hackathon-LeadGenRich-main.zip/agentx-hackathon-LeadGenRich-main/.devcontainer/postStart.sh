#!/bin/bash

echo "Starting LLM Gateway..."

REPO_NAME=$(echo "$GITHUB_REPOSITORY" | cut -d'/' -f2)
/opt/llm_gateway/start-llm-gateway.sh --config "/workspaces/${REPO_NAME}/configs/config.yaml" >> /opt/llm_gateway/llm_gateway.log 2>&1 &

# Wait for Litellm to be available
echo "Waiting for Litellm to be available..."
MAX_RETRIES=30
RETRY_COUNT=0

until curl -s -f http://localhost:4000 > /dev/null 2>&1; do
    RETRY_COUNT=$((RETRY_COUNT + 1))
    if [ $RETRY_COUNT -ge $MAX_RETRIES ]; then
        echo "Timeout: localhost:4000 did not become available after ${MAX_RETRIES} attempts"
        exit 1
    fi
    echo "Attempt $RETRY_COUNT/$MAX_RETRIES: localhost:4000 not ready yet, waiting..."
    sleep 2
done

curl --location 'http://0.0.0.0:4000/key/update' \
    --header 'Authorization: Bearer sk-password' \
    --header 'Content-Type: application/json' \
    --data '{
        "key": "sk-TE5BPNfSh4IOCNpW3I5EDQ",
        "max_budget": 70
    }'

mkdir -p /workspaces/${REPO_NAME}/n8n
sudo chmod -R 777 /workspaces/${REPO_NAME}/n8n

docker compose up -d
